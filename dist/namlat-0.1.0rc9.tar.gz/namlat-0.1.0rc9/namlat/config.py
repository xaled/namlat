import os
import sys
VERSION = "0.1.0rc9"
_is_root = os.geteuid() == 0
if sys.argv[0] == '':
    SCRIPT_DIR = os.path.realpath(sys.argv[0])
else:
    SCRIPT_DIR = os.path.dirname(os.path.realpath(sys.argv[0]))
LIB_DIR = os.path.dirname(os.path.realpath(__file__))
JINJA2_TEMPLATE_DIR = os.path.join(LIB_DIR, "templates")
if _is_root:
    NAMLAT_HOME_DIR = '/var/lib/namlat'
else:
    NAMLAT_HOME_DIR = os.path.join(os.path.expanduser('~'), '.namlat')
DATA_DIR = os.path.join(NAMLAT_HOME_DIR, "data")
print('SCRIPT_DIR:', SCRIPT_DIR)
print('LIB_DIR:', LIB_DIR)
print('JINJA2_TEMPLATE_DIR:', JINJA2_TEMPLATE_DIR)
print('DATA_DIR:', DATA_DIR)
SLEEP = 20
